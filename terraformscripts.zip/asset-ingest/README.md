# Asset Ingest

### /src

- Contains all application code


### /infra

- Contains all infrastructure code