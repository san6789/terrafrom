#!/bin/bash

az keyvault secret set --name AWS-AWSAccessKeyId --vault-name kv-mamintegrations-${ENV_RG} --value ${AWS_AWSAccessKeyId}
az keyvault secret set --name AWS-AWSSecretKeyId --vault-name kv-mamintegrations-${ENV_RG} --value ${AWS_AWSSecretKeyId}
az keyvault secret set --name AzureWebJobsStorageConnection --vault-name kv-mamintegrations-${ENV_RG} --value ${AzureWebJobsStorageConnection}
az keyvault secret set --name CosmosDB-ConnectionString --vault-name kv-mamintegrations-${ENV_RG} --value ${CosmosDBConnectionString}
az keyvault secret set --name StorageAccountConnectionString --vault-name kv-mamintegrations-${ENV_RG} --value ${StorageAccountConnectionString}
az keyvault secret set --name BlobStorage-StorageAccountKey --vault-name kv-mamintegrations-${ENV_RG} --value ${BlobStorageStorageAccountKey}
az keyvault secret set --name EventGridTopicKey --vault-name kv-mamintegrations-${ENV_RG} --value ${EventGridTopicKey}
az keyvault secret set --name Eventhub-Connection --vault-name kv-mamintegrations-${ENV_RG} --value ${EventHubConnection}
#az keyvault secret set --name Eventhub-Password --vault-name kv-mamintegrations-${ENV_RG} --value ${EventHubPassword}
az keyvault secret set --name TitleAPI-ApiMSubscriptionKey --vault-name kv-mamintegrations-${ENV_RG} --value ${TitleAPIApiMSubscriptionKey}
az keyvault secret set --name Wonderland-ClientAuth --vault-name kv-mamintegrations-${ENV_RG} --value "${Wonderland_ClientAuth}"
az keyvault secret set --name Wonderland-Username --vault-name kv-mamintegrations-${ENV_RG} --value ${Wonderland_Username}
az keyvault secret set --name Wonderland-Password --vault-name kv-mamintegrations-${ENV_RG} --value ${Wonderland_Password}
az keyvault secret set --name UserInfoAPIApiMSubscriptionKey --vault-name kv-mamintegrations-${ENV_RG} --value ${UserInfoAPIApiMSubscriptionKey}
az keyvault secret set --name JWTSecret --vault-name kv-mamintegrations-${ENV_RG} --value ${JWTSecret}
az keyvault secret set --name OpenIdClientSecret --vault-name kv-mamintegrations-${ENV_RG} --value ${OpenIdClientSecret}
az keyvault secret set --name ServiceBusConnectionString --vault-name kv-mamintegrations-${ENV_RG} --value ${ServiceBusConnectionString}
az keyvault secret set --name DMDClientId --vault-name kv-mamintegrations-${ENV_RG} --value ${DMDClientId}
az keyvault secret set --name DMDClientSecret --vault-name kv-mamintegrations-${ENV_RG} --value ${DMDClientSecret}
az keyvault secret set --name CosmosDB-DWLConnectionString --vault-name kv-mamintegrations-${ENV_RG} --value ${CosmosDBDWLConnectionString}
az keyvault secret set --name DownloadJWT-Secret --vault-name kv-mamintegrations-${ENV_RG} --value ${DownloadJWTSecret}
az keyvault secret set --name AssetServicesJWT-Secret --vault-name kv-mamintegrations-${ENV_RG} --value ${AssetServicesJWTSecret}
az keyvault secret set --name AssetServicesClientSecret --vault-name kv-mamintegrations-${ENV_RG} --value ${AssetServicesClientSecret}

