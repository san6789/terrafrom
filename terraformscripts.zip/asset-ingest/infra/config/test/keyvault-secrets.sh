#!/bin/bash

az keyvault secret set --name AWS-AWSAccessKeyId --vault-name ${KEYVAULT_NAME} --value "${AWS_AWSAccessKeyId}"
az keyvault secret set --name AWS-AWSSecretKeyId --vault-name ${KEYVAULT_NAME} --value "${AWS_AWSSecretKeyId}"
az keyvault secret set --name AzureWebJobsStorageConnection --vault-name ${KEYVAULT_NAME} --value "${AzureWebJobsStorageConnection}"
az keyvault secret set --name CosmosDB-ConnectionString --vault-name ${KEYVAULT_NAME} --value "${CosmosDBConnectionString}"
az keyvault secret set --name StorageAccountConnectionString --vault-name ${KEYVAULT_NAME} --value "${StorageAccountConnectionString}"
az keyvault secret set --name BlobStorage-StorageAccountKey --vault-name ${KEYVAULT_NAME} --value "${BlobStorageStorageAccountKey}"
az keyvault secret set --name EventGridTopicKey --vault-name ${KEYVAULT_NAME} --value "${EventGridTopicKey}"
az keyvault secret set --name Eventhub-Connection --vault-name ${KEYVAULT_NAME} --value "${EventHubConnection}"

az keyvault secret set --name TitleAPI-ApiMSubscriptionKey --vault-name ${KEYVAULT_NAME} --value "${TitleAPIApiMSubscriptionKey}"
az keyvault secret set --name Wonderland-ClientAuth --vault-name ${KEYVAULT_NAME} --value "${Wonderland_ClientAuth}"
az keyvault secret set --name Wonderland-Username --vault-name ${KEYVAULT_NAME} --value "${Wonderland_Username}"
az keyvault secret set --name Wonderland-Password --vault-name ${KEYVAULT_NAME} --value "${Wonderland_Password}"
az keyvault secret set --name UserInfoAPIApiMSubscriptionKey --vault-name ${KEYVAULT_NAME} --value "${UserInfoAPIApiMSubscriptionKey}"
az keyvault secret set --name JWTSecret --vault-name ${KEYVAULT_NAME} --value "${JWTSecret}"
az keyvault secret set --name OpenIdClientSecret --vault-name ${KEYVAULT_NAME} --value "${OpenIdClientSecret}"

az keyvault secret set --name CosmosDB-DWLConnectionString --vault-name ${KEYVAULT_NAME} --value "${CosmosDBDWLConnectionString}"
az keyvault secret set --name DownloadJWT-Secret --vault-name ${KEYVAULT_NAME} --value "${DownloadJWTSecret}"
az keyvault secret set --name AssetServicesJWT-Secret --vault-name ${KEYVAULT_NAME} --value "${AssetServicesJWTSecret}"
az keyvault secret set --name AssetServicesClientSecret --vault-name ${KEYVAULT_NAME} --value "${AssetServicesClientSecret}"
az keyvault secret set --name OpenIdClientId --vault-name ${KEYVAULT_NAME} --value "${OpenIdClientId}"

#az keyvault secret set --name Eventhub-Password --vault-name ${KEYVAULT_NAME} --value ${EventHubPassword}
#az keyvault secret set --name ServiceBusConnectionString --vault-name ${KEYVAULT_NAME} --value "${ServiceBusConnectionString}"
# az keyvault secret set --name DMDClientId --vault-name ${KEYVAULT_NAME} --value "${DMDClientId}"
# az keyvault secret set --name DMDClientSecret --vault-name ${KEYVAULT_NAME} --value "${DMDClientSecret}"